<?php

class ChatSql extends ConnectGeneral {

}

?>