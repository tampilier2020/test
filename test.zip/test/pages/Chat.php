<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <title>Chat</title>
    <script type="text/javascript">window.CHAT = {};</script>
    <script type="text/javascript" src="js/libs/jq.js"></script>
    <script type="text/javascript" src="js/Chat.js"></script>
</head>

<body class="area">
    <h1 align="center">Chat</h1>
    <div align="center">
        Name: <input type="text" />
    </div>
    <div align="center">
        <input type="button" value="Start" />
        <input type="button" value="Stop" />
    </div>

    <div align="center">
        <ul id="list"></ul>
    </div>
    <div align="center">
        <input type="text" id="text" /> <input type="button" value="Send" />
    </div>
</body>
</html>